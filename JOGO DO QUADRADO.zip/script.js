var up = document.getElementById("up");
var down = document.getElementById(
  "down");
var left = document.getElementById("left");
var right = document.getElementById("right");
var square = document.getElementById(
  "square");
var score = document.getElementById("score");
var objective = document.getElementById("objective");
var hiscore = document.getElementById("hiscore");
var resetBtn = document.getElementById("reset");
var start = document.getElementById("start");
var end = document.getElementById("end");
var ob1 = document.getElementById("obstacle1");
var ob2 = document.getElementById("obstacle2");
var ob3 = document.getElementById("obstacle3");
var escore = document.getElementById("endscore");
var ehiscore = document.getElementById("endhiscore");
var restartBtn = document.getElementById("restart");

up.addEventListener("touchstart", moveUpStart);
down.addEventListener("touchstart",
  moveDownStart);
left.addEventListener("touchstart", moveLeftStart);
right.addEventListener("touchstart", moveRightStart);
("restart");
up.addEventListener("touchend", moveUpEnd);
down.addEventListener("touchend",
  moveDownEnd);
left.addEventListener("touchend", moveLeftEnd);
right.addEventListener("touchend", moveRightEnd);
resetBtn.addEventListener("click", reset);
restartBtn.addEventListener("click", closeEnd)

var posX = 0;
var posY = 0;
var objX = 150;
var objY = 125;
var scoreNum = 0;
var hiscoreNum = 0;
var moveCount = 0;
var ob1Out = false;
var ob2Out = false;
var ob3Out = false;

var ob1X = -100;
var ob1Y = 0;
var ob1Down = true;
var ob1Up = false;

var ob2X = 0;
var ob2Y = -100;
var ob2Left = false;
var ob2Right = true;

var ob3X = 0;
var ob3Y = -100;
var ob3Left = false;
var ob3Right = true;
var ob3Up = true;
var ob3Down = false;

var uP;
var dowN;
var lefT;
var righT;

var clock = setInterval(moveCheck, 25)

if (localStorage.getItem("hiscore") > 0) {
  hiscoreNum = localStorage.getItem("hiscore");
  hiscore.innerHTML = "HI-SCORE: " + hiscoreNum;
}

function check(aa, ab, ba, bb, ca, cb, da, db, ea, eb) {
  if ((Math.abs(aa - ab) <= 30) && (Math.abs(ba - bb) <= 30)) {
    objX = randomNumX();
    objY = randomNumY();
    objective.style.marginTop = objY + 11 + "px";
    objective.style.marginLeft = objX + 11 + "px";
    scoreNum++;
    score.innerHTML = "SCORE: " + scoreNum;
    setHiscore();
    if (scoreNum === 10 && ob1Out === false)
    {
      ob1Out = true;
      ob1MoveX();
      ob1.style.display = "block";
    }
    if (scoreNum === 20 && ob2Out === false) {
      ob2Out = true;
      ob2MoveY();
      ob2.style.display = "block";
    }
    if (scoreNum === 30 && ob3Out === false)
    {
      ob3Out = true;
      ob3FirstX();
      ob3FirstY();
      ob3.style.display = "block";
    }
  }
  if ((Math.abs(aa - ca) <= 48) && (Math.abs(ba - cb) <= 48)) {
    end.style.display = "block";
    escore.innerHTML = "SCORE: " + scoreNum;
    ehiscore.innerHTML = "HI-SCORE: " + hiscoreNum;
    up.removeEventListener("touchstart", moveUpStart);
    down.removeEventListener("touchstart",
      moveDownStart);
    left.removeEventListener("touchstart", moveLeftStart);
    right.removeEventListener("touchstart", moveRightStart);
    resetBtn.removeEventListener("click", reset);
    restart();
  }
  if ((Math.abs(aa - da) <= 48) && (Math.abs(ba - db) <= 48)) {
    end.style.display = "block";
    escore.innerHTML = "SCORE: " + scoreNum;
    ehiscore.innerHTML = "HI-SCORE: " + hiscoreNum;
    up.removeEventListener("touchstart", moveUpStart);
    down.removeEventListener("touchstart",
      moveDownStart);
    left.removeEventListener("touchstart", moveLeftStart);
    right.removeEventListener("touchstart", moveRightStart);
    resetBtn.removeEventListener("click", reset);
    restart();
  }
  if ((Math.abs(aa - ea) <= 48) && (Math.abs(ba - eb) <= 48)) {
    end.style.display = "block";
    escore.innerHTML = "SCORE: " + scoreNum;
    ehiscore.innerHTML = "HI-SCORE: " + hiscoreNum;
    up.removeEventListener("touchstart", moveUpStart);
    down.removeEventListener("touchstart",
      moveDownStart);
    left.removeEventListener("touchstart", moveLeftStart);
    right.removeEventListener("touchstart", moveRightStart);
    resetBtn.removeEventListener("click", reset);
    restart();
  }
}

function reset() {
  posX = 0;
  posY = 0;
  objX = 150;
  objY = 125;
  ob1X = -100;
  ob1Y = 0;
  ob2X = 0;
  ob2Y = -100;
  ob3X = 0;
  ob3Y = -100;
  scoreNum = 0;
  hiscoreNum = 0;
  localStorage.setItem("hiscore", hiscoreNum);
  square.style.marginTop = posY + "px";
  square.style.marginLeft = posX + "px";
  objective.style.marginTop = objY + "px";
  objective.style.marginLeft = objX + "px";
  ob1.style.marginTop = ob1Y + "px";
  ob1.style.marginLeft = ob1X + "px";
  ob2.style.marginTop = ob2Y + "px";
  ob2.style.marginLeft = ob2X + "px";
  ob3.style.marginTop = ob3Y + "px";
  ob3.style.marginLeft = ob3X + "px";
  score.innerHTML = "SCORE: " + scoreNum;
  hiscore.innerHTML = "HI-SCORE: " + hiscoreNum;
  ob1.style.display = "none";
  ob2.style.display = "none";
  ob3.style.display = "none";
  ob1Out = false;
  ob2Out = false;
  ob3Out = false;
  ob1Down = true;
  ob1Up = false;
  ob2Left = false;
  ob2Right = true;
  ob3Down = false;
  ob3Up = true;
  ob3Left = false;
  ob3Right = true;
}

function restart() {
  posX = 0;
  posY = 0;
  objX = 150;
  objY = 125;
  ob1X = -100;
  ob1Y = 0;
  ob2X = 0;
  ob2Y = -100;
  ob3X = 0;
  ob3Y = -100;
  scoreNum = 0;
  square.style.marginTop = posY + "px";
  square.style.marginLeft = posX + "px";
  objective.style.marginTop = objY + "px";
  objective.style.marginLeft = objX + "px";
  ob2.style.marginTop = ob2Y + "px";
  ob2.style.marginLeft = ob2X + "px";
  ob1.style.marginTop = ob1Y + "px";
  ob1.style.marginLeft = ob1X + "px";
  ob3.style.marginTop = ob3Y + "px";
  ob3.style.marginLeft = ob3X + "px";
  score.innerHTML = "SCORE: " + scoreNum;
  hiscore.innerHTML = "HI-SCORE: " + hiscoreNum;
  ob1.style.display = "none";
  ob2.style.display = "none";
  ob3.style.display = "none";
  ob1Out = false;
  ob2Out = false;
  ob3Out = false;
  ob1Down = true;
  ob1Up = false;
  ob2Left = false;
  ob2Right = true;
  ob3Down = false;
  ob3Up = true;
  ob3Left = false;
  ob3Right = true;
}

function setHiscore() {
  if (scoreNum > hiscoreNum) {
    hiscoreNum = scoreNum;
    hiscore.innerHTML = "HI-SCORE: " + hiscoreNum;
    localStorage.setItem("hiscore", hiscoreNum);
  }
}

function randomNumX() {
  return ((Math.floor(Math.random() * 12) + 1) * 25);
}

function randomNumY() {
  return ((Math.floor(Math.random() * 10) + 1) * 25);
}

function moveUpStart() {
  uP = setInterval(moveUp, 25);
}

function moveUpEnd() {
  clearInterval(uP);
}

function moveUp() {
  if (posY >= 1) {
    posY = posY - 5;
  }
  square.style.marginTop = posY + "px";
  check(posX, objX, posY, objY, ob1X, ob1Y, ob2X, ob2Y, ob3X, ob3Y);
}

function moveDownStart() {
  dowN = setInterval(moveDown, 25);
}

function moveDownEnd() {
  clearInterval(dowN);
}

function moveDown() {
  if (posY <= 245) {
    posY = posY + 5;
  }
  square.style.marginTop = posY + "px";
  check(posX, objX, posY, objY, ob1X, ob1Y, ob2X, ob2Y, ob3X, ob3Y);
}

function moveLeftStart() {
  lefT = setInterval(moveLeft, 25);
}

function moveLeftEnd() {
  clearInterval(lefT);
}

function moveLeft() {
  if (posX >= 1) {
    posX = posX - 5;
  }
  square.style.marginLeft = posX + "px";
  check(posX, objX, posY, objY, ob1X, ob1Y, ob2X, ob2Y, ob3X, ob3Y);
}

function moveRightStart() {
  righT = setInterval(moveRight, 25);
}

function moveRightEnd() {
  clearInterval(righT);
}

function moveRight() {
  if (posX <= 295) {
    posX = posX + 5;
  }
  square.style.marginLeft = posX + "px";
  check(posX, objX, posY, objY, ob1X, ob1Y, ob2X, ob2Y, ob3X, ob3Y);
}

function hideStart() {
  start.style.display = "none";
}

function closeEnd() {
  end.style.display = "none";
  up.addEventListener("touchstart", moveUpStart);
  down.addEventListener("touchstart",
    moveDownStart);
  left.addEventListener("touchstart", moveLeftStart);
  right.addEventListener("touchstart", moveRightStart);
  resetBtn.addEventListener("click", reset);
}

function moveCheck() {
  if (ob1Out === true) {
    ob1MoveY();
    ob2Check();
    ob3Check();
    check(posX, objX, posY, objY, ob1X, ob1Y, ob2X, ob2Y, ob3X, ob3Y);
  }
}

function ob2Check() {
  if (ob2Out === true) {
    ob2MoveX();
  }
}

function ob3Check() {
  if (ob3Out === true) {
    ob3MoveX();
    ob3MoveY();
  }
}

function ob1MoveX() {
  ob1X = randomNumX();
  ob1.style.marginLeft = ob1X + "px";
}

function ob1MoveY() {
  if (ob1Down === true) {
    ob1Y = ob1Y + 2.5;
  }
  if (ob1Up === true) {
    ob1Y = ob1Y - 2.5;
  }
  ob1.style.marginTop = ob1Y + "px";
  if (ob1Y <= 1) {
    ob1Down = true;
    ob1Up = false;
  }
  if (ob1Y >= 250) {
    ob1Down = false;
    ob1Up = true;
  }
}

function ob2MoveY() {
  ob2Y = randomNumY();
  ob2.style.marginTop = ob2Y + "px";
}

function ob2MoveX() {
  if (ob2Left === true) {
    ob2X = ob2X - 2.5;
  }
  if (ob2Right === true) {
    ob2X = ob2X + 2.5;
  }
  ob2.style.marginLeft = ob2X + "px";
  if (ob2X <= 1) {
    ob2Right = true;
    ob2Left = false;
  }
  if (ob2X >= 300) {
    ob2Right = false;
    ob2Left = true;
  }
}

function ob3FirstX() {
  ob3X = randomNumX();
  ob3.style.marginLeft = ob3X + "px";
}

function ob3FirstY() {
  ob3Y = randomNumY();
  ob3.style.marginTop = ob3Y + "px";
}

function ob3MoveX() {
  if (ob3Left === true) {
    ob3X = ob3X - 2.5;
  }
  if (ob3Right === true) {
    ob3X = ob3X + 2.5;
  }
  ob3.style.marginLeft = ob3X + "px";
  if (ob3X <= 1) {
    ob3Left = false;
    ob3Right = true;
  }
  if (ob3X >= 300) {
    ob3Left = true;
    ob3Right = false;
  }
}

function ob3MoveY() {
  if (ob3Down === true) {
    ob3Y = ob3Y + 2.5;
  }
  if (ob3Up === true) {
    ob3Y = ob3Y - 2.5;
  }
  ob3.style.marginTop = ob3Y + "px";
  if (ob3Y <= 1) {
    ob3Down = true;
    ob3Up = false;
  }
  if (ob3Y >= 250) {
    ob3Down = false;
    ob3Up = true;
  }
}
